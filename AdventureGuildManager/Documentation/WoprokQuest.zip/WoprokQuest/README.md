# WoprokQuest
Woprok Quest is C++ application on topic of Adventure Guild Manager

## Topic
Téma môjho zápočťaku: Adventure guild manager (hra, a takmer určite to bude iba v konzole)
Hra kde hráč je šéf guildy a snaží sa s nej spraviť, čo najúspešnejšiu guildu. A ako tomu býva v rpg, tak dobrodruhovia(jeho zamestanci) sú úplne neschopný a neustále všetko kazia.

## Description
Pravdepodobne by to malo byť realtime, aj keď som si istý, že to skomplikuje všetko čo som dotiaľ rozmysel.
Hráč bude manažovať guildu, čo pozostáva z najímania hrdinov a posielania ich na Questy. Hrdinov bude môcť levelovať a spravovať ich výbavu. Časom sa budú objavovať Questy rôznej obťiažnosti.

### Cieľ hry: Získať čo najvyššie skóre.
Skóre(Sláva/Uznanie) je získavané s plnenia Quest-ov a z každého hrdinu, ktorí sa úspešne dožil dôchodku. V prípade smrti a neúspechu Quest-u skóre ubúda.

### Quest (Generované) pozostáva z:
- Reward(úspech) a Penaltu(neúspech)
- Čas po ktorí je možné poslať hrdinu aby sa ho pokúsil splniť.
- Cieľ je buď 1. Poraziť Monster, 2. Prekonať Skillcheck, 3. Kombinácia
- Na základe cieľov bude ukázaná očakávaná obtiažnosť.

### Hrdina, Monštrá (Generované + predefinované)
- Level určuje množstvo "schopností". Schopnosti sa budú dať predefinovať.
- Inventár obsahujúci predmety.
- na 99% nejaký základný stat predstavujúci život
- Vek
- Osobnosť (zoznam schopností, ktoré má rad a ktoré nemá rad)

### Groups
-umožniť organizovať a spoluprácu hrdinov na obťažných Quest-och
-level kooperácie (bonus z dlhodobej existencie bez zmien)
-pravdepodobne budú obsahovať nejaký preddefinovaný progress.
-možno nejaký system formácii, aby Combat nebol iba o hádzaní kocky.

### Guilda
-Aktuálna sláva a štatistika, ktorá bude určovať dostupné questy a dobrodruhov k najmutiu.
-rozšíritelne o nejaký progress system a resources.

### Combat a Skill system
-Pravdepodobne niečo založené na základoch D&D.


Myslím si, že už v tomto bode to bude veľa kódu ale ak by to bolo málo tak:
Nejaký systém, ktorí dodá monštram a hrdinom správanie, očakávania, ciele na základe, ktorích sa budú s času na čas rozhodovať na vlastnú päsť.


### Možné Rozšírenia (Skôr nerealistické ciele):
Encyklopédia, ktorí bude obsahovať informácie o svete, získaných z hrania.
Guildy a skupiny, ktoré budú súperiť o splnenie Quest-ov.
Questy, ktorých neúspech bude ohrozovať existenciu guildy.
Generovanie sveta. Vzťah sveta k guilde (Reputácia) Vzťahy medzi frakciami.
Multiplayer (je to lákave spomenúť ale takmer určite nie)
