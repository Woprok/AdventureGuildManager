﻿#ifndef EVENT_HPP
#define EVENT_HPP

#include <string>
#include <unordered_map>
#include <vector>
#include <functional>

template<typename T>
class SimpleEvent final
{
public:
	void addListener(const std::string& methodName, T namedEventHandlerMethod)
	{
		if (namedListeners.find(methodName) == namedListeners.end())
			namedListeners[methodName] = namedEventHandlerMethod;
	}

	void removeListener(const std::string& methodName)
	{
		if (namedListeners.find(methodName) != namedListeners.end())
			namedListeners.erase(methodName);
	}	

	std::vector<T> listeners()
	{
		std::vector<T> allListeners;
		for (auto listener : namedListeners)
		{
			allListeners.push_back(listener.second);
		}
		return allListeners;
	}
private:
	std::unordered_map<std::string, T> namedListeners;
};

#endif