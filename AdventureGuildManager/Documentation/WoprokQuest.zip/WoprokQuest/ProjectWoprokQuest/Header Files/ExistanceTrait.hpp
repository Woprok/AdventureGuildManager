﻿#ifndef EXISTANCE_TRAIT_HPP
#define EXISTANCE_TRAIT_HPP

#include "Trait.hpp"

static TraitBase ExistanceTrait = TraitBase("Existance", "Proof of your existance. Bad things happen to these who lose it!");

#endif