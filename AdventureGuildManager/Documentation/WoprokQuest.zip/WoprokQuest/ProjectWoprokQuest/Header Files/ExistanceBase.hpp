#ifndef EXISTANCE_BASE_HPP
#define EXISTANCE_BASE_HPP

#include <memory>
#include <vector>

#include "Type.hpp"
#include "Level.hpp"
#include "Age.hpp"
#include "Trait.hpp"

class ExistanceBase
{
public:
	inline const Type& GetType() const { return type; }
	inline const Age<int>& GetAge() const { return age; }
	inline LevelBase* GetLevel() const { return level.get(); }
	inline const std::vector<std::unique_ptr<TraitBase>>& GetTraits() const { return traits; }
private:
	Type type;
	Age<int> age;
	std::unique_ptr<LevelBase> level;
	std::vector<std::unique_ptr<TraitBase>> traits;
};

#endif