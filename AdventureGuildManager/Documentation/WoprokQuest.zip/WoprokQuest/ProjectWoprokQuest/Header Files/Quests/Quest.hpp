#ifndef QUEST_HPP
#define QUEST_HPP

class Quest
{
	//Provides all values so a quest can be called for evaluation
};

#endif