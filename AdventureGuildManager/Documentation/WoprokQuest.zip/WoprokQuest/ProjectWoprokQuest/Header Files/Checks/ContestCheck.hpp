﻿#ifndef CONTEST_CHECK_HPP
#define CONTEST_CHECK_HPP

#include "BaseCheck.hpp"

template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class ContestCheck : public BaseCheck<TNumber>
{
public:
	ContestCheck(std::seed_seq& SEED) : BaseCheck(SEED) {};
	~ContestCheck() override = default;
	CheckResultEnum Check(TNumber PCMOD, TNumber AIMOD) override
	{
		TNumber pcRollResult = BaseCheck<TNumber>::Roll();
		TNumber aiRollResult = BaseCheck<TNumber>::Roll();
		BaseCheck<TNumber>::pcRollResultValue = pcRollResult + PCMOD;
		aiRollResultValue = aiRollResult + AIMOD;

		if (BaseCheck<TNumber>::pcRollResultValue > aiRollResultValue)
		{
			BaseCheck<TNumber>::resultMessage =
				"Success: PC:[ROLL=" + pcRollResult + "][MODIFIER=" + PCMOD + "] vs AI:[ROLL=" + aiRollResult + "][MODIFIER=" + AIMOD + "]";
			BaseCheck<TNumber>::checkResult = CheckResultEnum::Success;
			return BaseCheck<TNumber>::checkResult;
		}
		else if (BaseCheck<TNumber>::pcRollResultValue == aiRollResultValue)
		{
			BaseCheck<TNumber>::resultMessage =
				"Draw: PC:[ROLL=" + pcRollResult + "][MODIFIER=" + PCMOD + "] vs AI:[ROLL=" + aiRollResult + "][MODIFIER=" + AIMOD + "]";
			BaseCheck<TNumber>::checkResult = CheckResultEnum::Draw;
			return BaseCheck<TNumber>::checkResult;
		}
		else // BaseCheck<TNumber>::pcRollResultValue < aiRollResultValue
		{
			BaseCheck<TNumber>::resultMessage =
				"Failure: PC:[ROLL=" + pcRollResult + "][MODIFIER=" + PCMOD + "] vs AI:[ROLL=" + aiRollResult + "][MODIFIER=" + AIMOD + "]";
			BaseCheck<TNumber>::checkResult = CheckResultEnum::Failure;
			return BaseCheck<TNumber>::checkResult;
		}
	}
	inline TNumber GetAiRollResult() const { return aiRollResultValue; }
private:
	TNumber aiRollResultValue = 0;
};

#endif