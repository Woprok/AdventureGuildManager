﻿#ifndef CHECK_RESULT_ENUM_HPP
#define CHECK_RESULT_ENUM_HPP

enum class CheckResultEnum
{
	Success,
	Draw,
	Failure
};

#endif