#ifndef BASE_CHECK_HPP
#define BASE_CHECK_HPP

#include <type_traits>
#include <string>
#include <random>
#include "CheckResultEnum.hpp"

template <typename TNumber, 
		  typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class BaseCheck
{
public:
	BaseCheck(std::seed_seq& SEED)
	{
		generator.seed(SEED);
		distribution(minimumValue, maximumValue);
	}
	virtual ~BaseCheck() = default;
	virtual CheckResultEnum Check(TNumber MOD, TNumber DC) = 0;
	inline TNumber GetPcRollResult() const { return pcRollResultValue; }
	inline const std::string& GetResultMessage() const { return resultMessage; }
	inline TNumber Roll() const { return distribution(generator); }
	inline CheckResultEnum GetResult() const { return checkResult; }
protected:
	std::default_random_engine generator;
	std::normal_distribution<TNumber> distribution;
	std::string resultMessage = "";
	TNumber pcRollResultValue = 0;
	CheckResultEnum checkResult = CheckResultEnum::Draw;
	TNumber minimumValue = 1;
	TNumber maximumValue = 20;
};

#endif