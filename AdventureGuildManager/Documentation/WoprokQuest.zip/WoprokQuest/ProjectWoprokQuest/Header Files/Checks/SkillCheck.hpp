﻿#ifndef SKILL_CHECK_HPP
#define SKILL_CHECK_HPP

#include "BaseCheck.hpp"

template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class SkillCheck : public BaseCheck<TNumber>
{
public:
	SkillCheck(std::seed_seq& SEED) : BaseCheck(SEED) {};
	~SkillCheck() override = default;
	CheckResultEnum Check (TNumber MOD, TNumber DC) override
	{
		TNumber rollResult = BaseCheck<TNumber>::Roll();
		BaseCheck<TNumber>::pcRollResultValue = rollResult + MOD;
		
		if (DC <= BaseCheck<TNumber>::pcRollResultValue)
		{
			BaseCheck<TNumber>::resultMessage =
				"Success: [ROLL=" + rollResult + "][MOD=" + MOD + "] vs [DC=" + DC + "]";
			BaseCheck<TNumber>::checkResult = CheckResultEnum::Success;
			return BaseCheck<TNumber>::checkResult;
		}
		else // DC > BaseCheck<TNumber>::pcRollResultValue
		{
			BaseCheck<TNumber>::resultMessage = 
				"Failure: [ROLL=" + rollResult + "][MOD=" + MOD + "] vs [DC=" + DC + "]";
			BaseCheck<TNumber>::checkResult = CheckResultEnum::Failure;
			return BaseCheck<TNumber>::checkResult;
		}
	}
};

#endif