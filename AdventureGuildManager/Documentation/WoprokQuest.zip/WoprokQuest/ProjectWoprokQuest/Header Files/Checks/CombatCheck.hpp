﻿#ifndef COMBAT_CHECK_HPP
#define COMBAT_CHECK_HPP

#include "BaseCheck.hpp"

//template <typename TNumber,
//	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
//class CombatCheck : public BaseCheck<TNumber>
//{
//public:
//	CombatCheck(std::seed_seq& SEED) : BaseCheck(SEED) {};
//	~CombatCheck() override = default;
//	CheckResultEnum Check(TNumber PCMOD, ExistanceBase& PCSTATS, TNumber AIMOD, ExistanceBase& AISTATS)
//	{
//		//ToDo maybe we don't need this at all ?
//		//Only reason would be critical hits
//		//Or making this able to solve whole combat ?
//	}
//private:
//
//};

#endif