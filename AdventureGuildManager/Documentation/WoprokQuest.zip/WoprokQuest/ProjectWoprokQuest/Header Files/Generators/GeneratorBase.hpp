﻿#ifndef GENERATOR_PARSER_HPP
#define GENERATOR_PARSER_HPP

#include <string>
#include <vector>
#include "../Quests/Quest.hpp"
#include "../Mechanics/Monster.hpp"
#include "../Mechanics/Adventurer.hpp"

class GeneratorBase
{

public:
	GeneratorBase() = default;
	~GeneratorBase() = default;
	Adventurer GenerateAdventurer();
	Monster GenerateMonster();
	Quest GenerateQuest();
protected:
	std::vector<Adventurer> adventurers;
	std::vector<Monster> monsters;
	std::vector<Quest> quests;
};

#endif