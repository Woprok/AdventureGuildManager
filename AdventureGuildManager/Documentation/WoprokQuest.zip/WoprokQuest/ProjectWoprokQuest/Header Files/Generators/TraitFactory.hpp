﻿#ifndef BASE_TRAIT_FACTORY_HPP
#define BASE_TRAIT_FACTORY_HPP

#include <string>
#include <memory>
#include <map>
#include <vector>
#include "BaseTraitCreator.hpp"
#include "../Traits/BaseTrait.hpp"

template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class TraitFactory
{
public:
	inline void Register(std::string&& IDENTIFIER, std::unique_ptr<BaseTraitCreator<TNumber>>&& CREATOR)
	{
		creators.insert(std::make_pair(IDENTIFIER, std::move(CREATOR)));
	}

	inline void ParseTrait(std::vector<std::string>& TRAIT)
	{
		for (auto && creator : creators)
		{
			if (creator.second->Create(TRAIT))
			{
				auto&& trait = creator.second->GetTrait();
				auto it = filtered_collections.find(creator.first);
				if (it != filtered_collections.end())
				{
					it->second.push_back(trait);
				}
				break;
			}
		}
	}

	inline void ParseCollection(std::vector<std::vector<std::string>>&& COLLECTION)
	{
		for (auto && vector : COLLECTION)
		{
			ParseTrait(vector);
		}
	}
protected:
	std::map<std::string, std::unique_ptr<BaseTraitCreator<TNumber>>> creators;
	std::map<std::string, std::vector<std::unique_ptr<BaseTrait<TNumber>>>> filtered_collections;
};

#endif