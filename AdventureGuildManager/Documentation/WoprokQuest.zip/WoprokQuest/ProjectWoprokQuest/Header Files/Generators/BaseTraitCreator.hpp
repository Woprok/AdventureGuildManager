﻿#ifndef BASE_TRAIT_CREATOR_HPP
#define BASE_TRAIT_CREATOR_HPP

#include <string>
#include <memory>
#include "../Traits/BaseTrait.hpp"
#include "../Traits/AbilityScoreTrait.hpp"

template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class BaseTraitCreator
{
public:
	BaseTraitCreator() = default;
	virtual ~BaseTraitCreator() = default;
	virtual bool Create(std::vector<std::string>& TRAIT)
	{
		if (TRAIT.size() == 4 && 
			TRAIT[0]._Starts_with(CONST_ID) && 
			TRAIT[1]._Starts_with(CONST_COST) &&
			TRAIT[2]._Starts_with(CONST_NAME) && 
			TRAIT[3]._Starts_with(CONST_DESCRIPTION))
		{
			trait = std::make_unique<BaseTrait<TNumber>>(
				std::stoll(TRAIT[0].substr(CONST_ID.size())),
				std::stoll(TRAIT[1].substr(CONST_COST.size())),
				TRAIT[2].substr(CONST_NAME.size()), 
				TRAIT[3].substr(CONST_DESCRIPTION.size()));
			return true;
		}
		return false;
	}
	virtual std::unique_ptr<BaseTrait<TNumber>>&& GetTrait()
	{
		return std::move(trait);
	}
protected:
	std::unique_ptr<BaseTrait<TNumber>> trait;
	inline static std::string CONST_ID = "ID|";
	inline static std::string CONST_COST = "COST|";
	inline static std::string CONST_NAME = "NAME|";
	inline static std::string CONST_DESCRIPTION = "DESCRIPTION|";
};

template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class AbilityScoreTraitCreator : BaseTraitCreator<TNumber>
{
public:
	AbilityScoreTraitCreator() = default;
	virtual ~AbilityScoreTraitCreator() = default;
	bool Create(std::vector<std::string>& TRAIT) override
	{
		if (TRAIT.size() == 6 && 
			TRAIT[0]._Starts_with(BaseTraitCreator<TNumber>::CONST_ID) && 
			TRAIT[1]._Starts_with(BaseTraitCreator<TNumber>::CONST_COST) &&
			TRAIT[2]._Starts_with(BaseTraitCreator<TNumber>::CONST_NAME) && 
			TRAIT[3]._Starts_with(BaseTraitCreator<TNumber>::CONST_DESCRIPTION) &&
			TRAIT[4]._Starts_with(CONST_STAT_ID) && 
			TRAIT[5]._Starts_with(CONST_BONUS))
		{
			as_trait = std::make_unique<AbilityScoreTrait<TNumber>>(
				std::stoll(TRAIT[0].substr(BaseTraitCreator<TNumber>::CONST_ID.size())),
				std::stoll(TRAIT[1].substr(BaseTraitCreator<TNumber>::CONST_COST.size())),
				TRAIT[2].substr(BaseTraitCreator<TNumber>::CONST_NAME.size()), 
				TRAIT[3].substr(BaseTraitCreator<TNumber>::CONST_DESCRIPTION.size()),
				TRAIT[4].substr(CONST_STAT_ID.size()), 
				std::stoll(TRAIT[5].substr(CONST_BONUS.size())));
			return true;
		}
		return false;
	}
	std::unique_ptr<BaseTrait<TNumber>>&& GetTrait() override
	{
		return std::move(as_trait);
	}
protected:
	std::unique_ptr<AbilityScoreTrait<TNumber>> as_trait;
	inline static std::string CONST_STAT_ID = "STAT_ID|";
	inline static std::string CONST_BONUS = "BONUS|";
};


#endif