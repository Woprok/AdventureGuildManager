﻿#ifndef PARSER_HPP
#define PARSER_HPP

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "StringHelpers.hpp"
#include <filesystem>
#include <vector>
#include <string>

class Parser
{
public:
	Parser() = default;
	~Parser() = default;

	//Parse all files with default file extension for traits
	void ParseAllAvailableTraits(const std::string& PATH)
	{
		collection.clear();
		auto&& result = ObtainTraitFiles(PATH);
		ParseTraits(result);
	}

	//Returns parsed collection
	inline std::vector<std::vector<std::string>> GetLoadedTraits() const { return collection; }
private:
	std::vector<std::string> ObtainTraitFiles(const std::string& PATH)
	{
		std::vector<std::string> tmp{};
		std::cerr << "sniffing around for *.wtrait" << std::endl;
		for (auto && directory_entry : std::filesystem::directory_iterator(std::filesystem::path(PATH).remove_filename()))
		{
			if (directory_entry.is_regular_file() && hlp::make_lowercase(directory_entry.path().extension().string()) == FILE_EXTENSION)
			{
				std::cerr << "Parsing: " << directory_entry.path() << std::endl;
				tmp.push_back(directory_entry.path().string());
			}
		}	
		return tmp;
	}

	void ParseTraits(const std::vector<std::string>& FILES)
	{
		for (auto && file : FILES)
		{
			OpenParseFile(file);
		}
	}

	void OpenParseFile(const std::string& FILENAME)
	{
		std::ifstream fileStream = std::ifstream(FILENAME, std::ios_base::in);
		Parse(fileStream);
		fileStream.close();
	}

	void Parse(std::ifstream& INPUT)
	{
		std::vector<std::string> trait;
		std::string field;
		while (std::getline(INPUT, field, ';'), !INPUT.fail())
		{
			hlp::trim(field);
			if (field._Starts_with(PREFIX_ID))
			{
				if (!trait.empty())
					collection.push_back(trait);
				trait = { field };
			}
			else
			{
				trait.push_back(field);
			}
		}
		if (!trait.empty())
			collection.push_back(trait);
	}

	inline static std::string FILE_EXTENSION = ".wtrait";
	inline static std::string PREFIX_ID = "ID|";
	std::vector<std::vector<std::string>> collection;
};

#endif