﻿#ifndef NUMERIC_HELPERS_HPP
#define NUMERIC_HELPERS_HPP

#include <type_traits>

namespace NumericHelpers
{
	template <typename  TNumber,
		typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
	inline bool CanAdd(const TNumber& a, const TNumber& b)
	{
		if (a == std::numeric_limits<TNumber>::max() || b == std::numeric_limits<TNumber>::max())
		{
			return false;
		}

	}


}

#endif