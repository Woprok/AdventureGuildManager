﻿#ifndef STRING_HELPERS_HPP
#define STRING_HELPERS_HPP

#include <algorithm> 
#include <cctype>
#include <locale>

namespace hlp //PS. skracovat string extension nie je dobry napad 
	//art of programming is also absorbing other people code, or why is this not part of std
{
	static inline std::string make_lowercase(const std::string& in)
	{
		std::string out;
		std::transform(in.begin(), in.end(), std::back_inserter(out), ::tolower);
		return out;
	}

	// trim from start (in place)
	static inline void ltrim(std::string &s)
	{
		s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](int ch)
		{
			return !std::isspace(ch);
		}));
	}

	// trim from end (in place)
	static inline void rtrim(std::string &s)
	{
		s.erase(std::find_if(s.rbegin(), s.rend(), [](int ch)
		{
			return !std::isspace(ch);
		}).base(), s.end());
	}

	// trim from both ends (in place)
	static inline void trim(std::string &s)
	{
		ltrim(s);
		rtrim(s);
	}

	// trim from start (copying)
	static inline std::string ltrim_copy(std::string s)
	{
		ltrim(s);
		return s;
	}

	// trim from end (copying)
	static inline std::string rtrim_copy(std::string s)
	{
		rtrim(s);
		return s;
	}

	// trim from both ends (copying)
	static inline std::string trim_copy(std::string s)
	{
		trim(s);
		return s;
	}
}
#endif