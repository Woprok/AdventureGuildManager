﻿#ifndef BASE_AGE_HPP
#define BASE_AGE_HPP

#include <type_traits>
#include <limits>

template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class BaseAge
{
public:
	BaseAge(TNumber STARTINGAGE, TNumber MAXAGE = std::numeric_limits<TNumber>::max())
	{
		BaseAge<TNumber>::currentAge = STARTINGAGE;
		BaseAge<TNumber>::maximumAge = MAXAGE;
	}
	virtual ~BaseAge() = default;
	inline TNumber GetCurrentAge() const { return currentAge; }
	inline TNumber GetCurrentMaximumAge() const { return maximumAge; }
	inline virtual void IncreaseAge(TNumber AMOUNT) = 0;
	inline virtual void IncreaseMaxAge(TNumber AMOUNT) = 0;
	inline virtual void DecreaseAge(TNumber AMOUNT) = 0;
	inline virtual void DecreaseMaxAge(TNumber AMOUNT) = 0;
	inline virtual bool OverMaxAge() = 0;
protected:
	TNumber currentAge = 0;
	TNumber maximumAge = 0;	
};

#endif