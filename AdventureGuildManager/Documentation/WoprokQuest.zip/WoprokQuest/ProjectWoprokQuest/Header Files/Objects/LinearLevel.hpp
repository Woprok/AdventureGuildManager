﻿#ifndef LINEAR_LEVEL_HPP
#define LINEAR_LEVEL_HPP

#include "BaseLevel.hpp"

//Todo add arithmetic overflow checks

template <typename TNumber,
		  typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class LinearLevel : public BaseLevel<TNumber>
{
public:
	LinearLevel(TNumber STARTING)
	{
		BaseLevel<TNumber>::currentLevel = STARTING;
		BaseLevel<TNumber>::currentExperience = STARTING * experiencePerLevelRequired;
	}
	~LinearLevel() override = default;
	virtual void IncreaseLevel(TNumber AMOUNT) override
	{
		IncreaseExperience(AMOUNT * experiencePerLevelRequired);
	};
	virtual void IncreaseExperience(TNumber AMOUNT) override
	{
		BaseLevel<TNumber>::currentExperience += AMOUNT;
		BaseLevel<TNumber>::currentLevel = AMOUNT / experiencePerLevelRequired;
	};
	virtual void DecreaseLevel(TNumber AMOUNT) override
	{
		DecreaseExperience(AMOUNT * experiencePerLevelRequired);		
	};
	virtual void DecreaseExperience(TNumber AMOUNT) override
	{
		BaseLevel<TNumber>::currentExperience -= AMOUNT;
		BaseLevel<TNumber>::currentLevel = AMOUNT / experiencePerLevelRequired;
	};
private:
	//Todo it would be awesome if this could be parameter one day
	static TNumber experiencePerLevelRequired = 1000;
};

#endif