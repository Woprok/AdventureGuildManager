﻿#ifndef SIMPLE_AGE_HPP
#define SIMPLE_AGE_HPP

#include "BaseAge.hpp"

//Todo add arithmetic overflow checks

template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class SimpleAge : public BaseAge<TNumber>
{
public:
	SimpleAge(TNumber STARTINGAGE, TNumber MAXAGE = std::numeric_limits<TNumber>::max())
		: BaseAge<TNumber>(STARTINGAGE, MAXAGE) { }
	virtual ~SimpleAge() override = default;
	inline virtual void IncreaseAge(TNumber AMOUNT) override
	{
		BaseAge<TNumber>::currentAge + AMOUNT;
	}
	inline virtual void IncreaseMaxAge(TNumber AMOUNT) override
	{
		BaseAge<TNumber>::maximumAge += AMOUNT;
	}
	inline virtual void DecreaseAge(TNumber AMOUNT) override
	{
		BaseAge<TNumber>::currentAge -= AMOUNT;
	}
	inline virtual void DecreaseMaxAge(TNumber AMOUNT) override
	{
		BaseAge<TNumber>::maximumAge -= AMOUNT;
	}
	inline virtual bool OverMaxAge() override { return BaseAge<TNumber>::currentAge > BaseAge<TNumber>::maximumAge; };
private:
};

#endif