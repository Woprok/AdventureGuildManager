﻿#ifndef TYPE_ENUM_HPP
#define TYPE_ENUM_HPP

enum class TypeEnum
{
	//Object
	Abiotic,
	//Living being
	Biotic
};

#endif