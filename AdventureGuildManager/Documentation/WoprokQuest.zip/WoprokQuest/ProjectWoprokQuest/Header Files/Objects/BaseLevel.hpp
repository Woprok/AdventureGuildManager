#ifndef BASE_LEVEL_HPP
#define BASE_LEVEL_HPP

#include <type_traits>

template <typename TNumber,
		  typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class BaseLevel
{
public:
	virtual ~BaseLevel() = default;
	TNumber GetCurrentLevel() const { return currentLevel; }
	TNumber GetCurrentExperience() const { return currentExperience; }
	inline virtual void IncreaseLevel(TNumber AMOUNT) = 0;
	inline virtual void IncreaseExperience(TNumber AMOUNT) = 0;
	inline virtual void DecreaseLevel(TNumber AMOUNT) = 0;
	inline virtual void DecreaseExperience(TNumber AMOUNT) = 0;
protected:
	TNumber currentLevel = 0;
	TNumber currentExperience = 0;
};

#endif