﻿#ifndef SCORE_HPP
#define SCORE_HPP

#include <type_traits>
#include "DifficultyEnum.hpp"

//Requires signed numeric type
template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class Score
{
public:
	Score(TNumber DIFFICULTY)
	{
		difficulty = DIFFICULTY;
		useableScore = 100 / DIFFICULTY; //harder difficulty decreases amount of points to start successful guild
	}
	virtual ~Score() = default;
	//value based on (Quest|Completed-Failed|+Adventurers|Retired-TPK|)*Difficulty
	TNumber GetScore() const 
	{ 
		//In theory this might work as expected or still be completely wrong idea
		return useableScore - usedScore + ((questCompleted - questFailed) / difficulty + (adventurerRetired - adventurerKilled) / difficulty) * difficulty;
	}
	//currency
	inline TNumber GetUseableScore() const { return useableScore; }
	//currency
	inline void UseScore(TNumber AMOUNT) const { usedScore += AMOUNT; }
	inline void QuestCompleted(TNumber COUNT) const { questCompleted += COUNT; }
	inline void QuestFailed(TNumber COUNT) const { questFailed += COUNT; }
	inline void AdventurerRetired(TNumber COUNT) const { adventurerRetired += COUNT; }
	inline void AdventurerKilled(TNumber COUNT) const {	adventurerKilled += COUNT; }
	inline void QuestCompleted() const { ++questCompleted; }
	inline void QuestFailed() const { ++questFailed; }
	inline void AdventurerRetired() const { ++adventurerRetired; }
	inline void AdventurerKilled() const {	++adventurerKilled;	}
protected:
	TNumber useableScore;
	TNumber usedScore = 0;
	TNumber difficulty = 0;
	TNumber questCompleted = 0;
	TNumber questFailed = 0;
	TNumber adventurerRetired = 0;
	TNumber adventurerKilled = 0;
};

#endif