﻿#ifndef TIME_TRACKER_HPP
#define TIME_TRACKER_HPP

#include <chrono>
#include <ctime>
#include <functional>
#include <thread>
#include <memory>
#include "../Public/SimpleEvent.hpp"

//Passes time as in real life, after some time passed creates event
class TimeTracker
{
	using TimePassed = std::function<void()>;
	using TimeValuePassed = std::function<void(std::time_t)>;
public:
	SimpleEvent<TimePassed>* HourPassed = new SimpleEvent<TimePassed>();
	SimpleEvent<TimePassed>* DayPassed = new SimpleEvent<TimePassed>();
	SimpleEvent<TimeValuePassed>* AmountPassed = new SimpleEvent<TimeValuePassed>();

	~TimeTracker()
	{
		IsRunning = false;
	}

	void Initialize()
	{
		IsRunning = true;
		StartTime = std::chrono::system_clock::now();
		LastTime = StartTime;
		minutesPassed = 0;
		timeThread = std::make_unique<std::thread>(&TimeTracker::ControlTime, this);
	}

	void ControlTime()
	{
		std::chrono::duration<long long> minutes;
		std::chrono::system_clock::time_point currentTime;

		while (IsRunning)
		{
			currentTime = std::chrono::system_clock::now();
			minutes = std::chrono::floor<std::chrono::minutes>(currentTime - LastTime);
			//ToDo stop ignoring cases when this does not happen every minute
			if (minutes.count() > 0)
			{
				LastTime = currentTime;
				++minutesPassed;
				RaiseHourPassed();
			}
		}
	}

	void Finish()
	{
		EndTime = std::chrono::system_clock::now();
		IsRunning = false;
		timeThread->join();
	}

	void RaiseHourPassed()
	{
		for (auto&& listener : HourPassed->listeners())
		{
			listener();
		}
	}	
	
	void RaiseDayPassed()
	{
		for (auto&& listener : DayPassed->listeners())
		{
			listener();
		}
	}

	void RaiseAmountPassed(std::time_t time)
	{
		for (auto&& listener : AmountPassed->listeners())
		{
			listener(time);
		}
	}

protected:
	std::chrono::system_clock::time_point StartTime;
	std::chrono::system_clock::time_point LastTime;
	std::chrono::system_clock::time_point EndTime;
	bool IsRunning = false;
	long long minutesPassed;
	std::unique_ptr<std::thread> timeThread;
};

#endif