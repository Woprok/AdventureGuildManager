#ifndef GAME_HPP
#define GAME_HPP

#include "DifficultyEnum.hpp"
#include "Score.hpp"
//#include "Guild.hpp"
#include "TimeTracker.hpp"
#include "Score.hpp"
#include "World.hpp"
#include <string>
#include "../Public/SimpleEvent.hpp"
#include <chrono>
#include <ctime>
#include <memory>
#include <vector>

template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class Game
{
public:
	Game(const std::string& PATH) 
	{
		world = World<TNumber>(PATH);
	}
	~Game() = default;

	void Start(TNumber DIFFICULTY)
	{
		tracker.Initialize();

		difficulty = static_cast<DifficultyEnum>(DIFFICULTY);
		score = Score(DIFFICULTY);

		BindListener();
	}

	bool ProcessLoop()
	{
		PrintGuide();
		std::string command;
		while (true)
		{
			std::cin >> command;

			if (command == "endgame")
			{
				std::cout << "Ending game!" << std::endl;
				EndGame();
				return false;
			}
			if (command == "restart")
			{
				std::cout << "Did you just restarted game weakling ?" << std::endl;
				EndGame();
				return true;
			}			
			if (command == "help")
			{
				std::cout << "How can you not remeber few words filthy peasant ?" << std::endl;
				PrintGuide();
				continue;
			}
			else 
			{
				ProcessCommand(command);
			}
		}
	}

	void EndGame()
	{
		UnbindListener();
		tracker.Finish();
	}

	void PostEndGame()
	{
		std::cout << "Congratulations you played worst game ever!";
	}

protected:
	World<TNumber> world;

	
	TimeTracker tracker = TimeTracker();
	//Current Score 
	Score<TNumber> score = Score<TNumber>(1);
	//Based on values increases quest and monster difficulty in theory...
	DifficultyEnum difficulty = DifficultyEnum::Normal;
private:
	TNumber timeTotal = 0;

	void ProcessCheat(const std::string& action)
	{
		//switch (action)
		//{
		//	case "cheat_complete_quest":;
		//	case "cheat_fail_quest":;
		//	case "cheat_retire_hero":;
		//	case "cheat_kill_hero":;
		//	default: ;
		//}	
	}
	void ProcessCommand(TNumber time)
	{
		std::cerr << "Processing time command " << time << std::endl;
		++timeTotal;
	}
	void ProcessCommand(const std::string& action)
	{
		std::cerr << "Processing text command: " << action << std::endl;
		if (action._Starts_with("cheat_"))
		{
			ProcessCheat(action);
		}
		if (action == "take")
		{
			
		}
		if (action == "hire")
		{
			
		}
	}

	void PrintGuide()
	{
		std::cout << "Welcome to worst attempt at Adventure Guild Manager!" << std::endl;
		std::cout << "Controls: just type command! It is not a rocket science, well maybe it is :D" << std::endl << "Commands: " << std::endl;
		std::cout << "endgame - suprisingly it does what it says!" << std::endl;
		std::cout << "restart - suprisingly it does what is says!" << std::endl;
		std::cout << "help - suprisingly it does what is says!" << std::endl;
		std::cout << "Do your best! Yes this is all the help you get." << std::endl;
	}

	void BindListener()
	{
		tracker.HourPassed->addListener("ProcessCommand", [&]()
		{
			ProcessCommand(1);
		});
	}
	void UnbindListener()
	{
		tracker.HourPassed->removeListener("ProcessCommand");
	}
};

#endif