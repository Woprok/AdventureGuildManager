﻿#ifndef MOSNTER_HPP
#define MOSNTER_HPP

class Monster
{
	//Based on BaseExistance
	//Provides all values that a classic monster needs
};

#endif