﻿#ifndef ADVENTURER_HPP
#define ADVENTURER_HPP

class Adventurer
{
	//Provides all adventurer values
	//Includes inventory
	//Personality is from trait
	//Stats are from traits
	//Base stats are from BaseExistance
};

#endif