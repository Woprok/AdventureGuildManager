﻿#ifndef WORLD_HPP
#define WORLD_HPP

#include "../Quests/Quest.hpp"
#include "../Generators/Parser.hpp"
#include "Monster.hpp"
#include "Adventurer.hpp"
#include "../Generators/TraitFactory.hpp"
#include "../Generators/GeneratorBase.hpp"

template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class World
{
public:
	World() {}
	World(const std::string& PATH) : World()
	{
		//load traits
		parser.ParseAllAvailableTraits(PATH);
		//returns collection of all traits
		//creates internal trait collection
		factory.ParseCollection(parser.GetLoadedTraits());
	}
	
	void Initialize()
	{
		//push trait to generator
		//generator.Initialize("factory.traits", "seed");

	}
private:
	Parser parser = Parser();

	//void GenerateMonster() {}
	//void GenerateAdventurer() {}
	//void GenerateQuest() {}
	//
	//
	//void ObtainAdventurer();
	//void AssignQuest();

	//Hold Heroes and Score
	//Guild PlayerGuild;
	//class Guild
	//{
	//	//Provides collection of heroes
	//	void AddHero(Adventurer recruited);
	//	void TakeQuest(Quest newQuest);
	//};
	//Parser
	//TraitFactory
	TraitFactory<TNumber> factory = TraitFactory<TNumber>();
	TraitFactory<TNumber> factory();
	//Generator
	//GeneratorBase generator = GeneratorBase();


	//Collection of active quests
	//std::vector<Quest> activeQuests;
	//
	//std::vector<Monster> generatedMonsters;
	//std::vector<Adventurer> freeAdventurers;

	//Collects for now all quests and monsters
	//serve as internal wikipedia for game to build on
	//so it contains also leveling option


	//predstavuje guildu a vsetko okolo nej
	//Guild ownedGuild;
	//Sleduje hru a realtime pocita dalsie stavy
	//Umoznut hracovi ujst z questu za cenu penalty
};

#endif