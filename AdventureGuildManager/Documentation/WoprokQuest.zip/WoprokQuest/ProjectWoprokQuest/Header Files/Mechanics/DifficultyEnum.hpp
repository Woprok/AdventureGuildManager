﻿#ifndef DIFFICULTY_ENUM_HPP
#define DIFFICULTY_ENUM_HPP

//For each level above normal monster gains bonus traits equal to number behind diff.
//This also mean that quest without fighting will potentially be superHard.
//Serves as XP penalty?? maybe not
enum class DifficultyEnum
{
	Easy = 1,
	Normal = 3,
	Hard = 5,
	Nightmare = 10,
	DungeonMasterHater = 100
};

#endif