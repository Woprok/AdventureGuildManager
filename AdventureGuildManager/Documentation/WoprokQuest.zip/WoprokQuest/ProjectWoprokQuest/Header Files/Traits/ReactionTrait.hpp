﻿#ifndef Reaction_TRAIT_HPP
#define Reaction_TRAIT_HPP

//#include "BonusTypeEnum.hpp"

//class ReactionTrait
//{
//protected:
//	BonusTypeEnum bonusType;
//	TNumber bonusValue;
//	TNumber targetId;
//
//	//***
//	//	Like / Dislike Trait contains
//	//
//	//	AFFECTED STAT(ID ? )
//	//	BONUS TYPE(advantage / disadvantage or numerical bonus if target has trait)
//	//	BONUS VALUE(only if numerical bonus type)
//	//
//	//	***
//};

#endif