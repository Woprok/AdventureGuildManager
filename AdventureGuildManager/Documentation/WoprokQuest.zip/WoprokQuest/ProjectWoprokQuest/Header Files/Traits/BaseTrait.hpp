#ifndef BASE_TRAIT_HPP
#define BASE_TRAIT_HPP

#include <string>

template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class BaseTrait
{
public:
	BaseTrait(TNumber ID, TNumber COST, std::string&& NAME, std::string&& DESCRIPTION)
	{
		id = ID;
		cost = COST;
		name = NAME;
		description = DESCRIPTION;
	}
	~BaseTrait() = default;

	inline TNumber GetId() const { return id; }
	inline TNumber GetCost() const { return cost; }
	inline const std::string& GetName() const { return name; }
	inline const std::string& GetDescription() const { return description; }
protected:
	TNumber id;
	TNumber cost;
	std::string name;
	std::string description;
};

#endif