﻿#ifndef BONUS_TYPE_ENUM_HPP
#define BONUS_TYPE_ENUM_HPP

enum class BonusTypeEnum
{
	Advantage,
	Disadvantage,
	PositiveModifier,
	NegativeModifier,
	Neutral
};

#endif