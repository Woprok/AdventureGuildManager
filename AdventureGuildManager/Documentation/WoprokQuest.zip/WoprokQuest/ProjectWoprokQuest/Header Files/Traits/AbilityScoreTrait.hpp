﻿#ifndef ABILITY_SCORE_TRAIT_HPP
#define ABILITY_SCORE_TRAIT_HPP

#include "BaseTrait.hpp"

template <typename TNumber,
	typename = typename std::enable_if<std::is_arithmetic<TNumber>::value, TNumber>::type>
class AbilityScoreTrait : BaseTrait<TNumber>
{
public:
	AbilityScoreTrait(TNumber ID, TNumber COST, std::string&& NAME, std::string&& DESCRIPTION,
	TNumber STATID, TNumber BONUS) 
	: BaseTrait<TNumber>(ID, COST, NAME, DESCRIPTION)
	{
		statId = STATID;
		statBonus = BONUS;
	}
	inline TNumber GetStatId() const { return statId; }
	inline TNumber GetStatBonus() const { return statBonus; }
protected:
	TNumber statId;
	TNumber statBonus;
};

#endif