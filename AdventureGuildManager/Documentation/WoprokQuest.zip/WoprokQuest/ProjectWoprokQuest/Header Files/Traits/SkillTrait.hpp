﻿#ifndef Skill_TRAIT_HPP
#define Skill_TRAIT_HPP

//class SkillTrait
//{
//
//};

#endif