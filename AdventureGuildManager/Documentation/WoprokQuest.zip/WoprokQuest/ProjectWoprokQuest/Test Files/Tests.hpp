#ifndef TESTS_HPP
#define TESTS_HPP

//ToDo Donutit sa pouzit framework, ale aktualne som az prilis iritovany z toho ze nechceli fungovat hned...

#include "../Header Files/Checks/BaseCheck.hpp"
#include "../Header Files/Checks/CheckResultEnum.hpp"
#include "../Header Files/Checks/SkillCheck.hpp"
#include "../Header Files/Checks/ContestCheck.hpp"

#include <iostream>
#include <random>
#include <ctime>

class Tests
{
	void RunTests()
	{
		TestSkill();
		TestContest();
	}

	inline void TestSkill()
	{
		std::seed_seq seed{ std::time(0) };
		SkillCheck<int> checkEngine(seed);
		std::cout << (checkEngine.Check(1, 1) == CheckResultEnum::Success);
		std::cout << (checkEngine.Check(-20, 1) == CheckResultEnum::Failure);
	}

	inline void TestContest()
	{
		std::seed_seq seed{ std::time(0) };
		ContestCheck<int> checkEngine(seed);

		std::cout << (checkEngine.Check(30, 1) == CheckResultEnum::Success);
		std::cout << (checkEngine.Check(1, 30) == CheckResultEnum::Failure);
	}
};

#endif