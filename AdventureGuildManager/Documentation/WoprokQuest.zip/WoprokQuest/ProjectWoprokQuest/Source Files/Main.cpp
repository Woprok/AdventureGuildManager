#include <iostream>
#include <cstdint>
#include <string>
#include <cassert>
#include <vector>
#include <string>

#include "../Header Files/Mechanics/Game.hpp"

int main(int argc, char* argv[])
{
	std::vector<std::string> arg(argv, argv + argc);
	std::int64_t difficulty = -1;
	Game<std::int64_t> game = Game<std::int64_t>(arg[0]);
	do
	{
		assert(difficulty < 0);
		while (difficulty != 1 && difficulty != 3 && difficulty != 5 && difficulty != 10 && difficulty != 100)
		{
			std::cout << "Select Difficulty: Easy = 1, Normal = 3, Hard = 5, Nightmare = 10, DungeonMasterHater = 100" << std::endl;
			std::cin >> difficulty;
		}
		
		std::cout << "Selected difficulty: " << difficulty << std::endl;
		assert(difficulty >= 0);
		game.Start(difficulty);
		difficulty = -1;
	}
	while (game.ProcessLoop());
	game.PostEndGame();
}